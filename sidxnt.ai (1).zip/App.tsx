
import React, { useState, useCallback } from 'react';
import { generateImage } from './services/geminiService';
import Loader from './components/Loader';
import Modal from './components/Modal';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const handleGenerate = useCallback(async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt to generate an image.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setImageUrl(null);
    try {
      const base64Image = await generateImage(prompt);
      setImageUrl(`data:image/png;base64,${base64Image}`);
    } catch (err) {
      setError('Failed to generate image. Please try again later.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [prompt]);

  const handleDownload = () => {
    if (!imageUrl) return;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${prompt.slice(0, 20).replace(/\s+/g, '_')}_sidxnt_ai.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const IconSparkles = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3a9 9 0 0 1 9 9 9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9z"></path>
        <path d="M8 12h8"></path>
        <path d="M12 8v8"></path>
    </svg>
  );

  return (
    <div className="min-h-screen bg-[#FDFBF6] text-zinc-800 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <header className="w-full max-w-4xl text-center mb-8">
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tighter">sidxnt.ai</h1>
        <p className="text-zinc-500 mt-2 text-lg">Bring your imagination to life.</p>
      </header>
      
      <main className="w-full max-w-xl flex-grow">
        <div className="space-y-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A cinematic shot of a curious fox in a lush, enchanted forest at twilight..."
            className="w-full p-4 text-base bg-white border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-400 focus:outline-none transition-shadow duration-200 shadow-sm resize-none"
            rows={4}
            disabled={isLoading}
          />
          <button
            onClick={handleGenerate}
            disabled={isLoading}
            className="w-full flex items-center justify-center bg-zinc-800 text-white font-semibold py-3 px-6 rounded-xl hover:bg-zinc-700 disabled:bg-zinc-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 shadow-md"
          >
            {isLoading ? (
              <>
                <Loader />
                Generating...
              </>
            ) : (
              'Generate Image'
            )}
          </button>
        </div>

        <div className="mt-8">
          {error && <p className="text-center text-red-500 bg-red-100 border border-red-200 p-3 rounded-lg">{error}</p>}
          
          <div className="w-full aspect-square bg-white border border-stone-200 rounded-2xl flex items-center justify-center mt-4 shadow-sm overflow-hidden">
            {isLoading ? (
              <div className="flex flex-col items-center text-zinc-500">
                <IconSparkles />
                <p className="mt-2 font-medium">Brewing up your creation...</p>
              </div>
            ) : imageUrl ? (
              <img src={imageUrl} alt={prompt} className="w-full h-full object-cover"/>
            ) : (
              <div className="text-center text-zinc-400 px-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="mt-2">Your generated image will appear here.</p>
              </div>
            )}
          </div>
          
          {imageUrl && !isLoading && (
            <div className="flex items-center justify-center space-x-4 mt-4">
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-white border border-stone-300 text-zinc-800 font-medium py-2 px-5 rounded-lg hover:bg-stone-100 transition-colors duration-200"
              >
                View
              </button>
              <button
                onClick={handleDownload}
                className="bg-zinc-800 text-white font-medium py-2 px-5 rounded-lg hover:bg-zinc-700 transition-colors duration-200"
              >
                Download
              </button>
            </div>
          )}
        </div>
      </main>

      <footer className="w-full max-w-4xl text-center mt-12 py-4">
        <p className="text-zinc-400 text-sm">&copy; {new Date().getFullYear()} sidxnt.ai. All rights reserved.</p>
      </footer>

      {isModalOpen && imageUrl && (
        <Modal imageUrl={imageUrl} alt={prompt} onClose={() => setIsModalOpen(false)} />
      )}
    </div>
  );
};

export default App;
