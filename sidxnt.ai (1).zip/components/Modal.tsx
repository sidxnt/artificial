
import React, { useEffect } from 'react';

interface ModalProps {
  imageUrl: string;
  alt: string;
  onClose: () => void;
}

const Modal: React.FC<ModalProps> = ({ imageUrl, alt, onClose }) => {
  
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="relative bg-white p-2 rounded-xl shadow-2xl max-w-4xl max-h-[90vh] w-auto h-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute -top-4 -right-4 bg-white text-zinc-800 rounded-full h-10 w-10 flex items-center justify-center text-2xl font-bold shadow-lg hover:bg-stone-200 transition-colors z-10"
          aria-label="Close"
        >
          &times;
        </button>
        <img
          src={imageUrl}
          alt={alt}
          className="max-w-full max-h-[85vh] h-auto w-auto object-contain rounded-lg"
        />
      </div>
    </div>
  );
};

export default Modal;
